/*
  Programmer: Tyler Schmitt
  Date: 23 November 2021
  Program: Functional Stacks
  Filename: conversion.cpp

  Description: A program to take a binary number and convert it to its 
               equivalent decimal value using an array-based stack, then 
               takes a decimal value and converts it to binary using
               a linked list-based stack.

  How to compile: g++ conversion.cpp

  How to execute: ./a.out
*/

#include <iostream>
#include <string>
#include <cmath>
#include "myStack.h"
#include "linkedStack.h"

using namespace std;

int main()
{

// BINARY TO DECIMAL
// -----------------

  int bit,bin,dec = 0, weight = 0;

  cout << "Please enter a binary number you would like to know the " <<
          "decimal equivalent of: ";
  cin >> bin; 


  // Create an array based stack to hold the binary digits
  stackType<int> binary;
  stackType<int> temp;
  binary.initializeStack();
  temp.initializeStack();


  // Inserts the binary digits into a stack
  while (bin > 0)
  {
    bit = bin % 10;
    temp.push(bit);
    
    bin = bin / 10;
  }


  // Inserts the digits into another stack, so the order that the 
  // calculations are done are correct
  while (!temp.isEmptyStack())
  {
    binary.push(temp.top());
    temp.pop();
  }


  // Finds the decimal value
  while (!binary.isEmptyStack())
  {
    dec = dec + binary.top() * (pow(2,weight));
   
    binary.pop();
    weight++;   
  }
  
  cout << "The decimal equivalent: " << dec << endl;
  cout << endl;



// DECIMAL TO BINARY
// -----------------

  cout << "Now enter a decimal value that you want to know "
       << "the binary equivalent of: ";
  cin >> dec;

    
  linkedStackType<int> binaryNum;
  binaryNum.initializeStack();

  // Pushes the binary digits into a linked list-based stack
  while (dec > 0)
  {
    binaryNum.push(dec % 2);    
  
    dec = dec/2;
  }

  // Output the binary number
  cout << "The binary equivalent: ";

  while (!binaryNum.isEmptyStack())
  {
    cout << binaryNum.top();

    binaryNum.pop();
  }
  
  cout << endl;

  return 0;



}
